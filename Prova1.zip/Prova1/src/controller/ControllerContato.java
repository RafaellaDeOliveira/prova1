package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import banco.dao.DaoContato;
import banco.entidades.Contato;

/**
 * Servlet implementation class ControllerContato
 */
@WebServlet("/ControllerContato")
public class ControllerContato extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerContato() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String operacao = request.getParameter("op");
		
		if (operacao.contentEquals("consultaTodos")) {
			DaoContato dao = new DaoContato();
			ArrayList<Contato> listaContato = dao.consultaTodos();

			HttpSession sessao = request.getSession(true);
			sessao.setAttribute("contatos", listaContato);
			response.sendRedirect("project-list.jsp");
		}else if(operacao.contentEquals("inserirContato")) {
			
			response.sendRedirect("basic-form-elements.jsp");
			
		}else if(operacao.contentEquals("addContato")) {
			
			DaoContato dao = new DaoContato();
			
			String nome = request.getParameter("nome");
			String telefone = request.getParameter("telefone");
			String email = request.getParameter("email");
			
			if(dao.insereContato(nome, telefone, email)) {
				String mensagem = "Contato adicionado";
				response.sendRedirect("project-list.jsp?m=" + mensagem);
			}else {
				String mensagem = "Falha ao adicionar contato";
				response.sendRedirect("project-list.jsp?m=" + mensagem);
			}
			
		}else {
			response.sendRedirect("index.jsp");
		}
	}

}
