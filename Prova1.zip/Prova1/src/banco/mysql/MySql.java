package banco.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySql {
	
	Connection conexao;
	Statement comando;
	
	public boolean carregaDriver() {
		boolean ok = false;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			ok = true;
		} catch (ClassNotFoundException e) {
			System.out.println("erro no driver:" + e.toString());
		}
		
		return ok;
	}
	
	public boolean conectarBanco() {
		boolean ok = false;
		
		try {
			conexao = DriverManager.getConnection("jdbc:mysql://localhost/agenda?user=admim&password=Jucabala123$&useTimezone=true&serverTimezone=UTC");
			ok = true;
		} catch (SQLException e) {
			System.out.println("erro na conexao:" + e.toString());
		}
		
		return ok;
	}
	
	public boolean preparaComando() {
		boolean ok = false;
		
		try {
			comando = conexao.createStatement();
			ok = true;
		} catch (SQLException e) {
			System.out.println("erro no comando:" + e.toString());
		}
		
		return ok;
	}
	
	public ResultSet consultaBanco(String sql) {
		ResultSet retorno = null;
		
		try {
			retorno = comando.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("erro no sql:" + e.toString() + " " + sql);
		}
		
		return retorno;
	}
	
	public int inserirBanco(String sql) {
		int resultado = 0;
				
		try {
			resultado = comando.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultado;
	}
	
	public void fechaBanco() {
		
		try {
			comando.close();
			conexao.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
