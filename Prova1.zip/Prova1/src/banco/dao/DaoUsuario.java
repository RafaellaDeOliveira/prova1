package banco.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import banco.mysql.MySql;

// DAO responsavel pelo sql

public class DaoUsuario {

	public boolean validaLogin(String email, String senha) {
		boolean valida = false;

		MySql banco = new MySql();

		if (banco.carregaDriver() && banco.conectarBanco() && banco.preparaComando()) {
			String sql = "SELECT * FROM usuario WHERE email='" + email + "' AND senha='" + senha + "' ";
			ResultSet r = banco.consultaBanco(sql);
			if (r != null) {
				try {
					if (r.next()) {
						valida = true;
						System.out.println(sql);
					} else {
						System.out.println(sql);
					}
				} catch (SQLException e) {
					System.out.println("erro:" + e.toString());
				}
			} else {
				System.out.println(sql);
			}
			
			banco.fechaBanco();

		}

		return valida;

	}

}
